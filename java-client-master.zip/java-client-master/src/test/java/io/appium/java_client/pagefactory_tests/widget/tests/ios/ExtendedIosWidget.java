package io.appium.java_client.pagefactory_tests.widget.tests.ios;

import org.openqa.selenium.WebElement;

public class ExtendedIosWidget extends AnnotatedIosWidget {
    protected ExtendedIosWidget(WebElement element) {
        super(element);
    }
}

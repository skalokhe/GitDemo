package io.appium.java_client.pagefactory_tests.widget.tests.windows;

import org.openqa.selenium.WebElement;

public class ExtendedWindowsWidget extends AnnotatedWindowsWidget {
    protected ExtendedWindowsWidget(WebElement element) {
        super(element);
    }
}
